# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '3527c1d54d763ae8eefc370ffa10d9af368c86d0b3bc665cd1b259a293cb2fef6ff0aa0b1e0f2b74d12f0675eb40efc5668821af2b18d85168e56b72e79d0754'